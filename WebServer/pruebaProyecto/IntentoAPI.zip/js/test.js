let button = document.querySelector('.button');
let inputValue = document.querySelector('.inputValue');
let cityName = document.querySelector('.cityName');
let desc = document.querySelector('.desc');
let temp = document.querySelector('.temp');
let jsonData = JSON.parse(city); 
//fetch('../data/city.json', cargaExitosa);

button.addEventListener('click',function(){
    
    //let id = jsonData['name'] == inputValue

    fetch('http://api.openweathermap.org/data/2.5/weather?id='+ inputValue.value +'&appid=3643e8e9b95f02e44f4cc6fe1a0d4521')
    .then(response => response.json())
    .then(data => {
        let nameValue = data['name'];
        let tempValue = data['main']['temp'];
        let descValue = data['weather'][0]['description'];

        cityName.innerHTML = nameValue;
        temp.innerHTML = tempValue;
        desc.innerHTML = descValue;
    })
      

.catch(err => alert("La ciudad que ha introducido no es válida"))
})

function cargaExitosa(json){
    jsonData = json;
    console.log(jsonData);
}