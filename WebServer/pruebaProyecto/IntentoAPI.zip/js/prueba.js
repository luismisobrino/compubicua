let jsonData = require('./data/city.json');
console.log(jsonData);
console.log(typeof(jsonData));